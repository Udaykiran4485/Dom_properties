// initialize variables
let operand1 = '';
let operand2 = '';
let operator = '';
let result = '';
const clearButton = document.getElementById('clear');
const divideButton = document.getElementById('divide');
const multiplyButton = document.getElementById('multiply');
const subtractButton = document.getElementById('subtract');
const addButton = document.getElementById('add');
const equalsButton = document.getElementById('equals');
const decimalButton = document.getElementById('decimal');
const zeroButton = document.getElementById('zero');
const oneButton = document.getElementById('one');
const twoButton = document.getElementById('two');
const threeButton = document.getElementById('three');
const fourButton = document.getElementById('four');
const fiveButton = document.getElementById('five');
const sixButton = document.getElementById('six');
const sevenButton = document.getElementById('seven');
const eightButton = document.getElementById('eight');
const nineButton = document.getElementById('nine');
const resultInput = document.getElementById('result');
const expressionParagraph = document.getElementById('expression');

// define functions
function clear() {
  operand1 = '';
  operand2 = '';
  operator = '';
  result = '';
  expressionParagraph.innerHTML = '';
  resultInput.value = '';
}

function addValue(value) {
  if (operator === '') {
    operand1 += value;
  } else {
    operand2 += value;
  }
  expressionParagraph.innerHTML = operand1 + ' ' + operator + ' ' + operand2;
}

function addDecimal() {
  if (operator === '' && operand1.indexOf('.') === -1) {
    operand1 += '.';
  } else if (operand2.indexOf('.') === -1) {
    operand2 += '.';
  }
  expressionParagraph.innerHTML = operand1 + ' ' + operator + ' ' + operand2;
}

function setOperator(value) {
  operator = value;
  expressionParagraph.innerHTML = operand1 + ' ' + operator;
}

function calculate() {
  const num1 = parseFloat(operand1);
  const num2 = parseFloat(operand2);
}
calculate();